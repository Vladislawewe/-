#include <stdio.h>

void main()
{
	int a, b;
	printf("Enter a:\n");
	scanf("%d", &a);
	
	printf("Enter b:\n");
	scanf("%d", &b);

	printf("c = %d\n", a+b);
}
